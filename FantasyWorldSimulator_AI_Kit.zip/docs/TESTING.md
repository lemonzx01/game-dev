# Testing, profiling and acceptance

## Correctness tests
- Fixed seed + identical command stream + supported build/config: compare canonical state/event hash at tick boundaries; test save/load continuation.
- Vital needs: starvation/dehydration and recovery follow rates, consumed resources decrease exactly once; no action for dead agents.
- Utility AI: different input scenarios pick feasible actions; blocked food or unavailable target cannot be selected; danger interrupt works; action commitment avoids endless switching.
- Ecology: a successful hunt consumes or transfers actual food; reproduction unique ID; check ecosystem under scarce food, winter, and predator growth. Extinction may be legitimate; investigate cause rather than forcing population survival.
- Social: directional trust; memory event linked to source; bounded low-value memory; no omniscient knowledge.
- Resource and economy: nonnegative inventories, conservation for trade, explicit source/sink events, no double spending of resources.
- Camera invariant: run same seed/commands with different camera movements or headless/rendered modes; simulation outcomes remain equal within documented determinism scope. Track/zoom commands should be presentation-only.
- Save: corrupted or incompatible save handled, existing save preserved, pending action and RNG restored.
- Performance optimizations: compare correctness baseline before/after. No skipping essential simulation when frame rate drops.

## Benchmark scenarios
1. Idle: 100/1,000/5,000/10,000 entities with basic needs.
2. Dense: many agents in small area, resource contention, path requests.
3. Ecology: mixed predator/prey and seasonal food; fixed seed.
4. Burst: many agents respond to one disaster event; bounded queue and timely emergency response.
5. Observer: render with zoom/pan/selection, compare with headless.
6. Long-run: simulate days/seasons, then years; target 100-year soak test in a later milestone. Track invariants, memory, population and causal events. Record actual simulated duration.

Start at 100, then 1,000 only if stable, larger populations after profiling; 100k is research. Run Release build when possible, record machine/spec, scenario, tick configuration, warmup, duration, seed, repeated runs. Measure p50/p95/p99 tick duration, ticks/sec, rendered frame time/FPS, RAM, allocations/GC, path queue and backlog. No claim of 60 FPS or population capacity without measurements. Establish regression threshold only after baseline (e.g. investigate >10% p95 degradation in comparable runs, not a universal pass rule).

## Human playtest
Let world run without input for 15–30 minutes; note what was interesting, why events occurred, whether NPC state makes sense, and whether UI helps inspect causes. Try hunger, danger, tracking an entity, save/reload and pause/speed. Note bugs and distinguish simulation flaws from intentional difficulty. Do not add feature solely because agent suggests it; owner prioritizes.

## Definition of done
Task acceptance in TASKS met with actual test/build evidence; no unrelated edits; documentation updated; asset provenance recorded; owner review where required. If verification cannot run, status remains REVIEW/BLOCKED with explanation.
