# Decisions and open questions

## Design decisions from project discussion
D001 Autonomous fantasy world: fun to observe without intervention. D002 Any chosen protagonist may die; no special protection. D003 Real dragons, diverse ordinary and magical animals; taming instead of spirit rings. D004 Civilized races including humans/demons build cities, can trade, ally and fight. D005 Survival, seasons, predator/prey, emotions, skills/books, trade/guards and wars. D006 Multiple worlds later, not just war. D007 God mode + observer + direct character control, command mode as later expansion.

## Proposed technical defaults (owner can revise before implementation)
A001 Godot 4 .NET + separate pure C# simulation; rationale: headless testing and rendering independence. A002 Utility AI first, GOAP later; no mandatory runtime LLM. A003 Stable IDs, fixed ticks, event scheduler, spatial grid, compact data; multithreading only when measured. A004 Modular top-down pixel art, placeholder/licensed assets first. A005 Shared repository and flexible AI ownership via handoff. A006 MVP smaller than long-term game, 20–100 initial NPCs, 100–1,000 initial benchmark entities; population of 100k is research.

## Open decisions — do not invent final answers
- Final game title, art style/palette, camera projection and exact sprite sizes.
- Exact Godot/.NET versions and minimum hardware; CPU benchmark before capacity claims.
- Time scale, day length, seasonal duration, reproduction rates, hunger/health balance.
- Species roster, magic taxonomy, religion/culture, inheritance, political rules and moral systems beyond confirmed design.
- How detailed combat, dungeon and multiworld simulations should be; long-term scope before implementation.
- Licensing for assets and distribution, modding format, release platform beyond initial Windows build.

## ADR template
ID/date/status (Proposed/Accepted/Superseded), problem, options, decision, rationale, consequences, affected contracts, owner approval, migration/test plan. Add new entries instead of silently changing shared contracts.
