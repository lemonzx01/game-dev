# Copy/paste prompts

Use a new coding session for each small task. Replace `<TASK_ID>` with actual ID. These prompts are manual entry points and work even if a tool does not auto-read its instruction file.

## Codex — first task
```text
You are the core simulation developer for this Godot 4 .NET / C# game.
Read AGENTS.md, GAME_DESIGN.md, ARCHITECTURE.md, TASKS.md and PROGRESS.md first. Follow the shared design invariants and ownership rules. Inspect existing repo and toolchain before creating files. Work ONLY on T001. Verify actual installed versions, propose the minimal project layout and simulation/presentation contract, record decisions and verification. Do not start other features or install large dependencies without approval. Keep changes focused. Update TASKS.md and PROGRESS.md with actual results and exact next steps. Stop after T001.
```

## Claude Code — review / architecture
```text
Read CLAUDE.md and AGENTS.md, then relevant sections of GAME_DESIGN.md, ARCHITECTURE.md, TASKS.md, PROGRESS.md and docs/TESTING.md. You are the architecture and senior reviewer. Review task <TASK_ID> and its diff, not the whole repo unless necessary. Prioritize correctness, simulation independence, resource conservation, determinism, performance and interface risks. Report concrete findings with severity, file/line and tests. Do not rewrite or edit code unless explicitly assigned. Record review evidence and handoff; stop at scope.
```

## Google Antigravity — presentation
```text
Read ANTIGRAVITY.md, AGENTS.md, GAME_DESIGN.md, ARCHITECTURE.md, TASKS.md and PROGRESS.md. You own Godot presentation and player interaction, not authoritative simulation rules. Work ONLY on T007 after T001 contract approval (or prepare a non-code UI/asset plan if blocked). Use placeholder or licensed assets. Render world snapshots, send validated commands, keep camera independent of gameplay. Use agreed contract, do not change core without approval. Test and record actual results and exact handoff in PROGRESS.md. Stop at assigned scope.
```

## Any agent — take over when quota runs out
```text
Read AGENTS.md, TASKS.md, PROGRESS.md and relevant GDD/architecture sections. Continue only <TASK_ID> from the latest recorded branch/commit and inspect git status/diff first. Preserve existing changes; do not restart or overwrite work. Identify remaining acceptance criteria, complete only the necessary work, run relevant tests and record actual results. If blocked or quota is low, leave concise handoff with exact next command. Stop after task.
```

## Session end reminder
```text
Do not start a new feature. Update PROGRESS.md with current Task ID, branch, changed files, actual commands/results, remaining issues and exact next action. Update TASKS status truthfully. Do not mark DONE if tests or acceptance are missing. Preserve all unrelated changes.
```
