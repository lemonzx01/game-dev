# Fantasy World Simulator — Shared AI Project Kit

ชุดเอกสารตั้งต้น v0.1 | ภาษาไทยสำหรับอธิบายเกม ภาษาอังกฤษสำหรับชื่อระบบและโค้ด | ยังไม่ใช่เกมที่พัฒนาแล้ว

## วิธีใช้
1. แตก ZIP แล้วคัดลอกไฟล์ในโฟลเดอร์นี้ไปไว้ที่ root ของ Git repository เกม (ไม่ต้องสร้าง root ซ้อน) ตรวจสอบไฟล์เดิมก่อนทับ
2. ใช้ Godot 4 .NET และ C# ตาม ARCHITECTURE.md; ตรวจสอบรุ่น Godot/.NET ที่ใช้จริงก่อนสร้างโค้ด
3. เปิด repository เดียวกันใน Codex, Claude Code และ Google Antigravity หรือใช้ Git worktree แยกกันหากทำพร้อมกัน
4. ส่งคำสั่งใน START_HERE.md ให้เครื่องมือแต่ละตัว โดยเลือก Task ID จาก TASKS.md
5. ทำทีละงาน ทดสอบจริง และบันทึกผลใน PROGRESS.md; อย่าเริ่มงานถัดไปเองจนกว่าจะได้รับอนุญาต

## แหล่งความจริงร่วมกัน (Single Source of Truth)
| ไฟล์ | หน้าที่ |
|---|---|
| GAME_DESIGN.md | วิสัยทัศน์ กฎของเกม และขอบเขตระยะยาว |
| ARCHITECTURE.md | ข้อตกลงทางเทคนิคและขอบเขต Simulation / Presentation |
| AGENTS.md | กฎกลางสำหรับ AI ทุกตัว |
| CLAUDE.md | จุดเริ่มสำหรับ Claude Code |
| ANTIGRAVITY.md | จุดเริ่มสำหรับ Antigravity (ให้อ่านโดย explicit prompt) |
| ROADMAP.md | แผน 30 วันและระยะถัดไป |
| TASKS.md | งานที่ได้รับมอบหมายและเกณฑ์ผ่าน |
| PROGRESS.md | สถานะล่าสุดและบันทึกส่งต่องาน |
| docs/TESTING.md | วิธีทดสอบ correctness, performance และ simulation |
| docs/DECISIONS.md | บันทึกการตัดสินใจและสิ่งที่ยังไม่ยืนยัน |
| START_HERE.md | Prompt เริ่มงานและรับช่วงต่อ |

เอกสารนี้เป็นข้อเสนอฐานที่เจ้าของเกมสามารถแก้ไขได้ ไม่ได้อ้างว่ามี source code, repository หรือผลทดสอบอยู่แล้ว หากพบความขัดแย้งให้หยุดเฉพาะส่วนที่ขัดแย้งและแจ้งเจ้าของเกม ไม่เดาเองหรือแก้เป้าหมายเกมโดยพลการ
