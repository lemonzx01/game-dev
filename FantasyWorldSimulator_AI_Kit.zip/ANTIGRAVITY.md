# Google Antigravity entry instructions

This portable instruction file is intended to be explicitly read via START_HERE.md; it does not claim automatic discovery by any particular Antigravity version.

Read AGENTS.md and follow the same common rules. Read GAME_DESIGN.md, ARCHITECTURE.md, TASKS.md and PROGRESS.md as directed there.

Role: Godot Presentation / Gameplay interface / asset integration. Own rendering, camera, UI, input, visual interpolation, selection, controls and inspection. Coordinate simulation contracts with Codex; do not implement a second authoritative world in Godot. Use placeholders and licensed assets first, record credits, profile rendering. When assigned core work after handoff, follow common rules and tests. Use focused task context to conserve quota.
