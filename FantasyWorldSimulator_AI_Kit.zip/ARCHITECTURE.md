# Software Architecture — v0.1

## 1. Stack / boundaries
Godot 4 .NET for presentation, pure C#/.NET for simulation, Git for version control. Exact SDK/engine versions are pending environment verification. Do not add external dependencies or a database server unless an ADR justifies it. No required cloud service or LLM at runtime.

```text
Repository/
  AGENTS.md ... shared docs
  Simulation/         Pure C# class library, no Godot references
    Core/             IDs, clock, world state, RNG, commands, events
    Systems/          Needs, AI, movement, resources, ecology, society
    Queries/          Read models, spatial index
    Persistence/      Save DTOs, versioning, migration
  Game/               Godot .NET project
    Presentation/     Rendering, camera, sprites, UI, input
    Integration/      Simulation adapter, snapshots, command submission
  Data/               Species, resources, actions, items, buildings
  Assets/             Licensed source art and credits
  Tests/              Unit, integration, headless scenarios, benchmarks
  docs/               Additional design / ADR / testing records
```
This is a proposed layout, not an assertion that files already exist. Keep Simulation independent of Game. Ensure .NET target compatibility with actual Godot project before committing solution layout; avoid duplicate compilation of source folders.

## 2. Authoritative world model
`WorldState` owns simulation data; only a simulation step mutates it. Use stable WorldId + EntityId (never use scene node path as identity). Separate simulation position from render interpolation. Use compact collections and typed IDs. Start with simple component-oriented arrays/collections and migrate hot spots after measurement; no full custom ECS framework required in MVP.

Proposed components: Identity, Transform, Vitals, LifeStage, Species, Needs, Personality, Emotions, Mind/CurrentAction, Inventory, SkillProgress, SocialLinks, SettlementMembership. Store sparse memory and relationships separately. Species definitions data-driven; all IDs validated. World resources have nonnegative amounts and explicit producers/consumers.

## 3. Contract between Codex and Antigravity
Proposed API names (freeze signatures after T001):
- `ISimulation.Step()` / fixed tick, `SubmitCommand(GameCommand)` and `ReadSnapshot()`.
- `WorldSnapshot`: world time, immutable render/query data with EntityId, position, species visual key, action, state; avoid full-world copy per rendered frame; use incremental snapshots/dirty regions when necessary.
- `EntityDetails`: selected entity, needs, traits, current action and reason, history summary.
- `WorldEvent`: tick, event kind, source/target IDs, location, causal reference optional.
- Commands: `SpawnEntity`, `SetSimulationSpeed`, `SetPaused`, `SetTrackedEntity` (UI-only where appropriate), and future `Possess`, `Move`, `Interact`. Validate commands in simulation; God commands explicit, never bypass silently.

Game reads immutable snapshots and submits commands. UI camera/zoom do not mutate gameplay. Simulation never accesses Godot Node/SceneTree. Renderer may interpolate position, never fabricate outcomes. Define DTOs in core or shared contracts, and use one owner per contract change. If a contract must change, record ADR and notify both implementers before changing callers.

## 4. Time and scheduling
- Fixed simulation step with integer tick/time; initial configurable target 10 simulation ticks per real second at 1× for prototype, tune by profiling. Render FPS independent. Speed multipliers schedule more ticks; if overloaded, slow effective speed or reduce noncritical presentation, show backlog, never skip gameplay time silently.
- Scheduler separates movement, decisions, needs, scheduled actions, environment and long-term systems. Stagger work using stable IDs; no all-agent decision spike at one tick.
- Actions: preconditions, target, duration, costs, effects, interrupt policy. Scheduled actions (e.g. sleep, reading) finish at due tick or wake on relevant event. Vital needs can be derived from elapsed time and updated at thresholds.
- Action commitment and cooldown prevent thrashing. Critical danger and active combat use bounded higher frequency.
- Stable ordering for conflicting writes and RNG; use seed + stable stream/event keys, not wall clock or thread scheduling. Same seed + commands + build/config should replay consistently; define supported determinism scope, do not promise cross-platform bitwise identity.

## 5. AI pipeline
Perceive local area and known places → derive needs/emotion → enumerate feasible actions → score utility (normalized, traits/risks) → choose action with deterministic tie break → execute/interrupt → emit event → update memories/beliefs. Track top candidates and reason in debug mode only; avoid logging every evaluation in production.
GOAP after baseline works: bounded depth/expansions, cache/retain viable plans, replan on invalidation, fall back to safe actions. FSM/behavior tree executes actions. Hierarchical organizations manage goals and orders; agents may accept/refuse. No omniscient NPC decisions; no per-agent LLM calls.

## 6. Spatial and pathfinding
Use chunk grid / spatial hash for local queries, update when entity changes cell. Query only bounded nearby cells and relevant entity type. Path requests queued with per-step budget; avoid synchronous pathfinding for every agent. MVP grid A* bounded, reuse paths when valid; region graph/hierarchical routes and flow fields for crowds later. Cache invalidation when terrain changes. Handle unreachable destinations and avoid infinite retries.

## 7. Scaling / simulation fidelity
Render LOD: cull off-screen, atlas/shared textures, pooled nodes or batched rendering where appropriate; zoom controls appearance only. Avoid creating permanent scene nodes for every living entity.
Simulation LOD: choose from activity, events, region load and importance independent of camera; distant idle individuals may use elapsed-time/scheduled action updates. Keep individual identity, resources, deaths, relationships and causal events. Coarse battle/economy must not be invented when camera returns. Define conservation/invariants and document approximation; if exact parity cannot be guaranteed, do not switch simulation rules based on camera. Important fights get high priority automatically regardless of observation. Camera tracking does not alter combat outcome.

## 8. Multithreading
Start deterministic single-threaded. Profile first. Add parallel jobs only for independent/read-only phases (e.g. score candidates from immutable state), then resolve commands in stable order on owner thread. No unsynchronized writes to world state; no Godot scene tree modifications by workers. Bound worker queue, avoid thread per agent. Keep tests comparing serial and parallel results. No C++ rewrite unless benchmark demonstrates justified bottleneck.

## 9. Persistence and events
Versioned save schema with seed, tick, RNG state/streams, stable IDs, entity/component data, resources, pending actions/events and relevant memory. Save at consistent tick boundary; temp write + replace with backup, validate before loading; never destroy previous save on failed write. Restore derived caches/indices. Define schema migration and test fixture. Use sparse relationships, bounded low-value memories, keep meaningful historical events; archive when necessary. Do not prune data needed for causal logic.

## 10. Performance and acceptance
Headless runner shares simulation library. Test 100, 1,000, 5,000, 10,000 entities progressively; 50k/100k are future research targets, not guaranteed. Measure p50/p95/p99 step time, throughput, managed allocations/GC, memory, path queue, rendered frame time, hardware/seed/scenario/config. Establish real baseline before asserting FPS. For 60 FPS target frame budget ~16.7ms, not a guarantee of simulation capacity. Prioritize responsiveness, no runaway backlog, no growing memory beyond expected state, and correct behavior. See docs/TESTING.md.
